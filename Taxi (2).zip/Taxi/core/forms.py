import re

from django import forms
from django.core.exceptions import ValidationError
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.password_validation import validate_password

from .models import AdminUser, User


class CustomerRegistrationForm(forms.ModelForm):
    password = forms.CharField(
        label="Password",
        strip=False,
        widget=forms.PasswordInput(
            attrs={"autocomplete": "new-password"},
        ),
    )

    class Meta:
        model = User
        fields = ("name", "email", "password", "mobile")
        field_order = ("name", "email", "password", "mobile")
        labels = {"mobile": "Phone"}
        widgets = {
            "name": forms.TextInput(attrs={"autocomplete": "name"}),
            "email": forms.EmailInput(attrs={"autocomplete": "email"}),
            "mobile": forms.TextInput(
                attrs={"autocomplete": "tel", "inputmode": "tel"}
            ),
        }

    def clean_name(self):
        name = self.cleaned_data["name"].strip()
        if not name:
            raise forms.ValidationError("Enter your name.")
        return name

    def clean_email(self):
        email = self.cleaned_data["email"].strip()
        existing_user = User.objects.filter(email__iexact=email)
        if self.instance.pk:
            existing_user = existing_user.exclude(pk=self.instance.pk)
        if existing_user.exists():
            raise forms.ValidationError("A user with this email already exists.")
        return email

    def clean_mobile(self):
        mobile = self.cleaned_data["mobile"].strip()
        if not re.fullmatch(r"\+?[0-9().\-\s]+", mobile):
            raise forms.ValidationError(
                "Enter a valid phone number using digits and common phone symbols."
            )

        digit_count = sum(character in "0123456789" for character in mobile)
        if not 7 <= digit_count <= 15:
            raise forms.ValidationError(
                "Enter a phone number containing 7 to 15 digits."
            )
        return mobile

    def clean_password(self):
        password = self.cleaned_data["password"]
        validate_password(password, self.instance)
        return password

    def save(self, commit=True):
        customer = super().save(commit=False)
        customer.set_password(self.cleaned_data["password"])
        if commit:
            customer.save()
        return customer


class CustomerLoginForm(forms.Form):
    email = forms.EmailField(
        widget=forms.EmailInput(
            attrs={"autocomplete": "email", "autocapitalize": "none"}
        ),
    )
    password = forms.CharField(
        strip=False,
        widget=forms.PasswordInput(
            attrs={"autocomplete": "current-password"},
        ),
    )


class AdminRegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    phone = forms.CharField(
        label="Phone",
        max_length=20,
        required=True,
        widget=forms.TextInput(
            attrs={"autocomplete": "tel", "inputmode": "tel"}
        ),
    )

    class Meta(UserCreationForm.Meta):
        model = AdminUser
        fields = ("username", "email", "phone")


class CustomerUserForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ("name", "email", "mobile")
        widgets = {
            "name": forms.TextInput(attrs={"autocomplete": "name"}),
            "email": forms.EmailInput(attrs={"autocomplete": "email"}),
            "mobile": forms.TextInput(
                attrs={"autocomplete": "tel", "inputmode": "tel"}
            ),
        }


class AdminPasswordResetRequestForm(forms.Form):
    email = forms.EmailField()


class AdminPasswordResetOTPForm(forms.Form):
    otp = forms.RegexField(
        regex=r"^\d{6}$",
        max_length=6,
        min_length=6,
        widget=forms.TextInput(
            attrs={"autocomplete": "one-time-code", "inputmode": "numeric"}
        ),
    )


class AdminSetNewPasswordForm(forms.Form):
    new_password1 = forms.CharField(
        label="New password",
        widget=forms.PasswordInput,
    )
    new_password2 = forms.CharField(
        label="Confirm new password",
        widget=forms.PasswordInput,
    )

    def __init__(self, *args, user=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.user = user

    def clean(self):
        cleaned_data = super().clean()
        password1 = cleaned_data.get("new_password1")
        password2 = cleaned_data.get("new_password2")

        if password1 and password2:
            if password1 != password2:
                self.add_error("new_password2", "The passwords do not match.")
            else:
                try:
                    validate_password(password1, self.user)
                except ValidationError as error:
                    self.add_error("new_password1", error)

        return cleaned_data
